from config.config_loader import Config

# Crear instancia global
config = Config()